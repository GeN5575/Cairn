# Cairn (Android)

Le jeu Cairn dans une coque Android (WebView). Le jeu lui-même est dans
`app/src/main/assets/index.html`, avec ses polices dans `assets/fonts/`. Il fonctionne hors ligne.

## Obtenir l'APK avec GitHub

1. Crée un dépôt GitHub (public, c'est le plus simple pour télécharger depuis le téléphone).
2. Envoie-y tout le contenu de ce dossier, dossier caché `.github` compris, sur la branche `main`.
3. Ouvre l'onglet **Actions** : la compilation « Build APK » démarre toute seule (environ 3 à 5 minutes).
4. Quand elle est verte, l'APK est disponible de deux façons :
   - dans l'onglet **Releases**, version « Cairn (APK) », fichier `cairn.apk` ;
   - dans le résumé de la compilation, sous **Artifacts**.
5. Télécharge `cairn.apk` sur ton téléphone et ouvre-le. Android te demandera d'autoriser
   l'installation depuis cette source (navigateur ou gestionnaire de fichiers).

Lien de téléchargement stable, à remplacer par ton compte et ton dépôt :
`https://github.com/TON_COMPTE/TON_DEPOT/releases/latest/download/cairn.apk`

## Compiler soi-même

Avec Android Studio : ouvrir ce dossier, puis **Build > Build APK(s)**.
En ligne de commande (SDK Android et Java 17 installés) : `./gradlew assembleDebug`.
L'APK est dans `app/build/outputs/apk/debug/`.

## Notes

- L'APK est signé avec la clé de debug d'Android : il s'installe sans problème sur un téléphone,
  mais il n'est pas prévu pour le Play Store.
- Android 8.0 ou plus récent.
- Les polices (Bricolage Grotesque, DM Mono) sont sous licence SIL OFL, voir `app/src/main/assets/fonts/`.
