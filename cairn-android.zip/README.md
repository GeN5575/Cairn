# Cairn (Android)

Le jeu Cairn dans une coque Android (WebView). Le jeu lui-même est dans
`app/src/main/assets/index.html`, avec ses polices dans `assets/fonts/`. Il fonctionne hors ligne.

## Obtenir l'APK avec GitHub

1. Crée un dépôt GitHub (public, c'est le plus simple pour télécharger depuis le téléphone).
2. Envoie-y tout le contenu de ce dossier, dossier caché `.github` compris, sur la branche `main`.
3. Ouvre l'onglet **Actions** : la compilation « Build APK » démarre toute seule (environ 3 à 5 minutes).
4. Quand elle est verte, l'APK est disponible de deux façons :
   - dans l'onglet **Releases**, version « Cairn (APK) », fichier `cairn.apk` ;
   - dans le résumé de la compilation, sous **Artifacts**.
5. Télécharge `cairn.apk` sur ton téléphone et ouvre-le. Android te demandera d'autoriser
   l'installation depuis cette source (navigateur ou gestionnaire de fichiers).

Lien de téléchargement stable, à remplacer par ton compte et ton dépôt :
`https://github.com/TON_COMPTE/TON_DEPOT/releases/latest/download/cairn.apk`

## Compiler soi-même

Avec Android Studio : ouvrir ce dossier, puis **Build > Build APK(s)**.
En ligne de commande (SDK Android et Java 17 installés) : `./gradlew assembleDebug`.
L'APK est dans `app/build/outputs/apk/debug/`.

## Notes

- L'APK est signé avec la clé de debug d'Android : il s'installe sans problème sur un téléphone,
  mais il n'est pas prévu pour le Play Store.
- Android 8.0 ou plus récent.
- Les polices (Bricolage Grotesque, DM Mono) sont sous licence SIL OFL, voir `app/src/main/assets/fonts/`.

## Mettre le jeu à jour

Le dépôt GitHub contient `cairn-android.zip` et le fichier `.github/workflows/android.yml`.
Pour changer le jeu, il suffit d'envoyer un nouveau `index.html` à la racine du dépôt
(page « Add file > Upload files »). La compilation repart toute seule et publie un nouvel APK
dans Releases. L'APK est toujours signé avec la même clé (`cairn.keystore`), donc Android
l'installe par-dessus l'ancienne version, sans rien perdre (scores et réglages inclus).
La clé étant dans le dépôt, elle n'est pas secrète : c'est suffisant pour un jeu installé à la main,
mais pas pour une publication sur le Play Store.
