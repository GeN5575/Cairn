package fr.cairn.game;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.DisplayCutout;
import android.view.RoundedCorner;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#1d2340"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        // long press blocked in the game, but still allowed in the save-code box (select / copy / paste)
        web.setOnLongClickListener(v -> web.getHitTestResult().getType() != WebView.HitTestResult.EDIT_TEXT_TYPE);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                    // saves scores and settings
        s.setMediaPlaybackRequiresUserGesture(false);    // lets the music start right away
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) { pushInsets(); }
        });
        // keeps texts and buttons away from the camera notch and the rounded corners of the screen
        web.setOnApplyWindowInsetsListener((v, wi) -> { readInsets(wi); return v.onApplyWindowInsets(wi); });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        hideBars();
    }

    private float insTop = 0, insBottom = 0;

    private void readInsets(WindowInsets wi) {
        float d = getResources().getDisplayMetrics().density;
        int t = 0, b = 0;
        if (Build.VERSION.SDK_INT >= 28) {
            DisplayCutout c = wi.getDisplayCutout();
            if (c != null) { t = c.getSafeInsetTop(); b = c.getSafeInsetBottom(); }
        }
        if (Build.VERSION.SDK_INT >= 31) {
            RoundedCorner tl = wi.getRoundedCorner(RoundedCorner.POSITION_TOP_LEFT);
            RoundedCorner bl = wi.getRoundedCorner(RoundedCorner.POSITION_BOTTOM_LEFT);
            if (tl != null) t = Math.max(t, Math.round(tl.getRadius() * 0.35f));
            if (bl != null) b = Math.max(b, Math.round(bl.getRadius() * 0.35f));
        } else {
            t = Math.max(t, Math.round(12 * d));   // older phones: a small safety margin
            b = Math.max(b, Math.round(12 * d));
        }
        insTop = t / d; insBottom = b / d;
        pushInsets();
    }

    private void pushInsets() {
        if (web == null) return;
        String js = "(function(){var r=document.documentElement.style;r.setProperty('--st','" + insTop + "px');r.setProperty('--sb','" + insBottom + "px');window.dispatchEvent(new Event('resize'));})()";
        web.evaluateJavascript(js, null);
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) { hideBars(); web.requestApplyInsets(); }
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        hideBars();
    }

    // Back button: the game closes the open panel, pauses, or returns to the menu; it only quits from the main menu
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.cairnBack ? window.cairnBack() : false", v -> {
            if (!"true".equals(v)) finish();
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        web.destroy();
    }
}
